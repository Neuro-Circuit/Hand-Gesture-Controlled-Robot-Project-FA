"""
نقطه ورود برنامه. تصویر وب‌کم را می‌خواند، حرکات هر دو دست (به‌طور مستقل) و داده کامل
ریگ آن‌ها را تشخیص می‌دهد، شکل هندسی بین دو دست را (در صورت دیده شدن هر دو) می‌سازد،
و دستورات خروجی را بلادرنگ از طریق سینک‌های پیکربندی‌شده منتشر می‌کند.

سه کانال خروجی به‌طور هم‌زمان در دسترس‌اند:
  - نمایشگر زنده در مرورگر: http://127.0.0.1:8000  (تصویر دوربین + نقاط دست + لاگ دستورات)
  - API بلادرنگ (WebSocket) برای هر برنامه دیگر: ws://127.0.0.1:8765
  - پنجره محلی OpenCV (اختیاری، برای دیباگ سریع بدون باز کردن مرورگر)

اجرا:
    python main.py
    python main.py --no-window     # بدون پنجره محلی OpenCV (نمایشگر وب همچنان فعال است)
    python main.py --no-web        # بدون سرور وب (فقط پنجره محلی + WebSocket API)

خروج از برنامه: کلید q یا Esc در پنجره محلی، یا Ctrl+C در ترمینال
"""
import argparse
import time

import cv2
import yaml

from core.hand_tracker import HandTracker
from core.dispatcher import GestureManager

from core.gestures.movement import HandMovementDetector
from core.gestures.fist import FistDetector
from core.gestures.pinch_rub import PinchRubDetector
from core.gestures.finger_point import FingerPointSwipeDetector
from core.gestures.thumbs import ThumbDetector
from core.gestures.open_palm_swipe import OpenPalmSwipeDetector
from core.gestures.hand_rig import HandRigEmitter
from core.gestures.two_hand_frame import TwoHandFrameDetector

from core.output.console_sink import ConsoleSink
from core.output.json_log_sink import JSONLogSink
from core.output.websocket_sink import WebSocketSink

from core.web.broadcaster import FrameBroadcaster
from core.web.server import start_web_server


def load_config(path="config/gestures.yaml"):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def build_detectors(config):
    """
    یک مجموعه *تازه* از تمام تشخیص‌گرهای تک‌دست فعال می‌سازد. این تابع به‌عنوان یک
    «کارخانه» به GestureManager داده می‌شود و برای هر دست ('Left'/'Right') جداگانه
    فراخوانی می‌شود - تا حافظه/تاریخچه هر دست کاملاً مستقل بماند.

    برای افزودن حرکت تک‌دست جدید، کلاس آن را در core/gestures/ بسازید
    (نمونه در examples/custom_gesture_example.py) و یک نمونه از آن را اینجا اضافه
    کنید - نیازی به تغییر جای دیگری نیست.
    """
    return [
        HandMovementDetector(config),
        FistDetector(config),
        PinchRubDetector(config),
        FingerPointSwipeDetector(config),
        ThumbDetector(config),
        OpenPalmSwipeDetector(config),
        HandRigEmitter(config),
    ]


def build_two_hand_detectors(config):
    """
    تشخیص‌گرهایی که به هر دو دست هم‌زمان نیاز دارند (مثل شکل هندسی بین دو دست).
    برخلاف build_detectors، اینجا یک نمونه مشترک کافی است چون فقط یک «جفت دست» وجود دارد.
    برای افزودن قابلیت دودستی جدید، از TwoHandDetector ارث‌بری کنید و اینجا اضافه کنید.
    """
    return [
        TwoHandFrameDetector(config),
    ]


def build_sinks(config):
    out_cfg = config.get("output", {})
    sinks = []

    c_cfg = out_cfg.get("console", {})
    if c_cfg.get("enabled", True):
        sinks.append(ConsoleSink(categories=c_cfg.get("categories"), mode=c_cfg.get("mode", "numeric")))

    j_cfg = out_cfg.get("json_log", {})
    if j_cfg.get("enabled", True):
        sinks.append(JSONLogSink(j_cfg.get("path", "logs/commands_log.jsonl"),
                                  categories=j_cfg.get("categories")))

    w_cfg = out_cfg.get("websocket", {})
    if w_cfg.get("enabled", False):
        try:
            sinks.append(WebSocketSink(w_cfg.get("host", "127.0.0.1"),
                                        w_cfg.get("port", 8765),
                                        categories=w_cfg.get("categories")))
        except RuntimeError as e:
            print(f"[main] خروجی وب‌سوکت غیرفعال شد: {e}")

    return sinks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-window", action="store_true",
                         help="اجرا بدون پنجره محلی OpenCV (نمایشگر وب همچنان فعال است)")
    parser.add_argument("--no-web", action="store_true",
                         help="غیرفعال کردن سرور وب، حتی اگر در تنظیمات فعال باشد")
    parser.add_argument("--config", default="config/gestures.yaml")
    args = parser.parse_args()

    config = load_config(args.config)
    cam_cfg = config.get("camera", {})
    web_cfg = config.get("output", {}).get("web", {})
    web_enabled = web_cfg.get("enabled", True) and not args.no_web

    tracker = HandTracker(config)
    manager = GestureManager(
        detector_factory=lambda: build_detectors(config),
        two_hand_detectors=build_two_hand_detectors(config),
        sinks=build_sinks(config),
    )

    broadcaster = None
    if web_enabled:
        broadcaster = FrameBroadcaster()
        start_web_server(broadcaster, config)

    cap = cv2.VideoCapture(cam_cfg.get("index", 0))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, cam_cfg.get("width", 640))
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, cam_cfg.get("height", 480))

    if not cap.isOpened():
        print("خطا: دوربین در دسترس نیست.")
        return

    show_window = not args.no_window
    need_drawing = show_window or web_enabled  # رسم اسکلت دست فقط اگر جایی نمایش داده می‌شود

    prev_t = time.time()
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame = cv2.flip(frame, 1)
            results = tracker.process(frame)

            seen_labels = set()
            hands_by_label = {}

            if results.hand_landmarks:
                for idx, hand_landmarks in enumerate(results.hand_landmarks):
                    label = (results.handedness[idx][0].category_name
                             if results.handedness else "Right")
                    seen_labels.add(label)
                    hands_by_label[label] = hand_landmarks
                    manager.process_hand(hand_landmarks, frame.shape, label)

            manager.end_frame(seen_labels)

            if "Left" in hands_by_label and "Right" in hands_by_label:
                manager.process_pair(hands_by_label["Left"], hands_by_label["Right"], frame.shape)
            else:
                manager.reset_pair()

            if need_drawing:
                tracker.draw(frame, results)
                now = time.time()
                fps = 1.0 / max(now - prev_t, 1e-6)
                prev_t = now
                cv2.putText(frame, f"FPS: {fps:.1f}", (10, 25),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            if broadcaster is not None:
                broadcaster.update(frame)

            if show_window:
                cv2.imshow("Hand Gesture Control", frame)
                if cv2.waitKey(1) & 0xFF in (ord('q'), 27):
                    break
    except KeyboardInterrupt:
        pass
    finally:
        cap.release()
        cv2.destroyAllWindows()
        tracker.close()
        manager.close()


if __name__ == "__main__":
    main()
